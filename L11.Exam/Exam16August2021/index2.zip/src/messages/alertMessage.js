export const ALL_FIELDS_ARE_REQUIRED_MESSAGE = () => alert('All fields are required!');

export const PASSWORDS_MUST_MATCH_MESSAGE = () => alert('Passwords must match!');

export const ENTER_VALID_COMMENT_MESSAGE = () => alert('Enter valid comment!');

export const DELETE_GAME_CONFIRM_MESSAGE = () => confirm('Do you want to delete this game?');