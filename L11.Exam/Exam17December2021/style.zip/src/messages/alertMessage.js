export const ALL_FIELDS_ARE_REQUIRED_ERROR = () => {
    throw new Error('All fields are required!');
}

export const PASSWORDS_MUST_MATCH_ERROR = () => {
    throw new Error('Passwords must match!');
}