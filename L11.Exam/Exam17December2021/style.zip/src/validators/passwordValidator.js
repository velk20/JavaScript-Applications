export const passwordValidator = (pass, confPass) => {
    return pass == confPass;
}